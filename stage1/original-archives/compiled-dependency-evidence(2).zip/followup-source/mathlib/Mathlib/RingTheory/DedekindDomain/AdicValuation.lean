/-
Copyright (c) 2022 María Inés de Frutos-Fernández. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: María Inés de Frutos-Fernández
-/
module

public import Mathlib.Algebra.Order.Ring.IsNonarchimedean
public import Mathlib.Data.Int.WithZero
public import Mathlib.RingTheory.DedekindDomain.Dvr
public import Mathlib.RingTheory.DedekindDomain.Ideal.Lemmas
public import Mathlib.RingTheory.Valuation.ExtendToLocalization
public import Mathlib.Topology.Algebra.Valued.WithVal
public import Mathlib.RingTheory.Valuation.Discrete.Basic

/-!
# Adic valuations on Dedekind domains

Given a Dedekind domain `R` of Krull dimension 1 and a maximal ideal `v` of `R`, we define the
`v`-adic valuation on `R` and its extension to the field of fractions `K` of `R`.
We prove several properties of this valuation, including the existence of uniformizers.

We define the completion of `K` with respect to the `v`-adic valuation, denoted
`v.adicCompletion`, and its ring of integers, denoted `v.adicCompletionIntegers`.

## Main definitions
- `IsDedekindDomain.HeightOneSpectrum.intValuation v` is the `v`-adic valuation on `R`.
- `IsDedekindDomain.HeightOneSpectrum.valuation v` is the `v`-adic valuation on `K`.
- `IsDedekindDomain.HeightOneSpectrum.adicCompletion v` is the completion of `K` with respect
  to its `v`-adic valuation.
- `IsDedekindDomain.HeightOneSpectrum.adicCompletionIntegers v` is the ring of integers of
  `v.adicCompletion`.
- `IsDedekindDomain.HeightOneSpectrum.adicAbv v` is the `v`-adic absolute value on `K` defined as
  `b` raised to negative `v`-adic valuation, for some `b` in `ℝ≥0`.

## Main results
- `IsDedekindDomain.HeightOneSpectrum.intValuation_le_one` : The `v`-adic valuation on `R` is
  bounded above by 1.
- `IsDedekindDomain.HeightOneSpectrum.intValuation_lt_one_iff_dvd` : The `v`-adic valuation of
  `r : R` is less than 1 if and only if `v` divides the ideal `(r)`.
- `IsDedekindDomain.HeightOneSpectrum.intValuation_le_pow_iff_dvd` : The `v`-adic valuation of
  `r : R` is less than or equal to `WithZero.exp (-n)` if and only if `vⁿ` divides the
  ideal `(r)`.
- `IsDedekindDomain.HeightOneSpectrum.intValuation_exists_uniformizer` : There exists `π : R`
  with `v`-adic valuation `WithZero.exp (-1)`.
- `IsDedekindDomain.HeightOneSpectrum.valuation_of_mk'` : The `v`-adic valuation of `r / s : K`
  is the valuation of `r` divided by the valuation of `s`.
- `IsDedekindDomain.HeightOneSpectrum.valuation_of_algebraMap` : The `v`-adic valuation on `K`
  extends the `v`-adic valuation on `R`.
- `IsDedekindDomain.HeightOneSpectrum.valuation_exists_uniformizer` : There exists `π : K` with
  `v`-adic valuation `WithZero.exp (-1)`.

## Implementation notes
We are only interested in Dedekind domains with Krull dimension 1.

## References
* [G. J. Janusz, *Algebraic Number Fields*][janusz1996]
* [J.W.S. Cassels, A. Fröhlich, *Algebraic Number Theory*][cassels1967algebraic]
* [J. Neukirch, *Algebraic Number Theory*][Neukirch1992]

## Tags
dedekind domain, dedekind ring, adic valuation
-/

@[expose] public section

noncomputable section

open WithZero Multiplicative IsDedekindDomain

variable {R : Type*} [CommRing R] [IsDedekindDomain R] {K S : Type*} [Field K] [CommSemiring S]
  [Algebra R K] [IsFractionRing R K] (v : HeightOneSpectrum R)

namespace IsDedekindDomain.HeightOneSpectrum

/-! ### Adic valuations on the Dedekind domain R -/

open scoped Classical in
/-- The additive `v`-adic valuation of `r : R` is the exponent of `v` in the factorization of the
ideal `(r)`, if `r` is nonzero, or infinity, if `r = 0`. `intValuationDef` is the corresponding
multiplicative valuation. -/
def intValuationDef (r : R) : ℤᵐ⁰ :=
  if r = 0 then 0
  else
    exp (-(Associates.mk v.asIdeal).count (Associates.mk (Ideal.span {r} : Ideal R)).factors : ℤ)

theorem intValuationDef_if_pos {r : R} (hr : r = 0) : v.intValuationDef r = 0 :=
  if_pos hr

@[simp]
theorem intValuationDef_zero : v.intValuationDef 0 = 0 :=
  if_pos rfl

theorem intValuationDef_if_neg {r : R} (hr : r ≠ 0) :
    v.intValuationDef r = exp
        (-(Associates.mk v.asIdeal).count (Associates.mk (Ideal.span {r} : Ideal R)).factors : ℤ) :=
  if_neg hr

/-- The `v`-adic valuation of `0 : R` equals 0. -/
theorem intValuation.map_zero' : v.intValuationDef 0 = 0 :=
  v.intValuationDef_if_pos rfl

/-- The `v`-adic valuation of `1 : R` equals 1. -/
theorem intValuation.map_one' : v.intValuationDef 1 = 1 := by
  rw [v.intValuationDef_if_neg one_ne_zero, Ideal.span_singleton_one, ← Ideal.one_eq_top,
    Associates.mk_one, Associates.factors_one, Associates.count_zero v.associates_irreducible,
    Int.ofNat_zero, neg_zero, exp_zero]

/-- The `v`-adic valuation of a product equals the product of the valuations. -/
theorem intValuation.map_mul' (x y : R) :
    v.intValuationDef (x * y) = v.intValuationDef x * v.intValuationDef y := by
  simp only [intValuationDef]
  by_cases hx : x = 0
  · rw [hx, zero_mul, if_pos rfl, zero_mul]
  · by_cases hy : y = 0
    · rw [hy, mul_zero, if_pos rfl, mul_zero]
    · rw [if_neg hx, if_neg hy, if_neg (mul_ne_zero hx hy), ← exp_add,
        ← Ideal.span_singleton_mul_span_singleton, ← Associates.mk_mul_mk, ← neg_add,
        Associates.count_mul (Associates.mk_ne_zero'.mpr hx) (Associates.mk_ne_zero'.mpr hy)
          v.associates_irreducible,
        Nat.cast_add]

-- TODO: unused, this is general over any linear order
theorem intValuation.le_max_iff_min_le {a b c : ℕ} :
    Multiplicative.ofAdd (-c : ℤ) ≤
      max (Multiplicative.ofAdd (-a : ℤ)) (Multiplicative.ofAdd (-b : ℤ)) ↔
      min a b ≤ c := by
  rw [le_max_iff, ofAdd_le, ofAdd_le, neg_le_neg_iff, neg_le_neg_iff, Int.ofNat_le, Int.ofNat_le,
    ← min_le_iff]

/-- The `v`-adic valuation of a sum is bounded above by the maximum of the valuations. -/
theorem intValuation.map_add_le_max' (x y : R) :
    v.intValuationDef (x + y) ≤ max (v.intValuationDef x) (v.intValuationDef y) := by
  by_cases hx : x = 0
  · rw [hx, zero_add]
    order
  · by_cases hy : y = 0
    · rw [hy, add_zero]
      order
    · by_cases hxy : x + y = 0
      · rw [intValuationDef, if_pos hxy]; exact zero_le
      · rw [v.intValuationDef_if_neg hxy, v.intValuationDef_if_neg hx, v.intValuationDef_if_neg hy,
          le_max_iff]
        simp only [exp_le_exp, neg_le_neg_iff, Nat.cast_le, ← min_le_iff]
        set nmin :=
          min ((Associates.mk v.asIdeal).count (Associates.mk (Ideal.span {x})).factors)
            ((Associates.mk v.asIdeal).count (Associates.mk (Ideal.span {y})).factors)
        have h_dvd_x : x ∈ v.asIdeal ^ nmin := by
          rw [← Associates.le_singleton_iff x nmin _,
            Associates.prime_pow_dvd_iff_le (Associates.mk_ne_zero'.mpr hx) _]
          · exact min_le_left _ _
          exact v.associates_irreducible
        have h_dvd_y : y ∈ v.asIdeal ^ nmin := by
          rw [← Associates.le_singleton_iff y nmin _,
            Associates.prime_pow_dvd_iff_le (Associates.mk_ne_zero'.mpr hy) _]
          · exact min_le_right _ _
          exact v.associates_irreducible
        have h_dvd_xy : Associates.mk v.asIdeal ^ nmin ≤ Associates.mk (Ideal.span {x + y}) := by
          rw [Associates.le_singleton_iff]
          exact Ideal.add_mem (v.asIdeal ^ nmin) h_dvd_x h_dvd_y
        rw [Associates.prime_pow_dvd_iff_le (Associates.mk_ne_zero'.mpr hxy) _] at h_dvd_xy
        · exact h_dvd_xy
        exact v.associates_irreducible

/-- The `v`-adic valuation on `R`. -/
def intValuation : Valuation R ℤᵐ⁰ where
  toFun := v.intValuationDef
  map_zero' := intValuation.map_zero' v
  map_one' := intValuation.map_one' v
  map_mul' := intValuation.map_mul' v
  map_add_le_max' := intValuation.map_add_le_max' v

theorem intValuation_apply {r : R} (v : IsDedekindDomain.HeightOneSpectrum R) :
    intValuation v r = intValuationDef v r := rfl

open scoped Classical in
theorem intValuation_def {r : R} :
    v.intValuation r = if r = 0 then 0 else
    exp (-(Associates.mk v.asIdeal).count (Associates.mk (Ideal.span {r} : Ideal R)).factors : ℤ) :=
  rfl

theorem intValuation_if_neg {r : R} (hr : r ≠ 0) :
    v.intValuation r = exp
        (-(Associates.mk v.asIdeal).count (Associates.mk (Ideal.span {r} : Ideal R)).factors : ℤ) :=
  intValuationDef_if_neg _ hr

theorem intValuation_eq_exp_neg_multiplicity {r : R} (hr : r ≠ 0) :
    v.intValuation r = exp (-multiplicity v.asIdeal (Ideal.span {r}) : ℤ) := by
  have hsr : Ideal.span {r} ≠ 0 := Submodule.span_singleton_eq_bot.mp.mt hr
  have hfm : FiniteMultiplicity v.asIdeal (Ideal.span {r}) :=
    FiniteMultiplicity.of_prime_left v.prime hsr
  rw [v.intValuation_if_neg hr, exp_inj, neg_inj, Int.natCast_inj, ← ENat.natCast_inj,
    ← FiniteMultiplicity.emultiplicity_eq_multiplicity hfm,
    UniqueFactorizationMonoid.emultiplicity_eq_count_normalizedFactors (irreducible v) hsr,
    normalize_eq, Ideal.count_associates_factors_eq hsr v.isPrime v.ne_bot]

/-- Nonzero elements have nonzero adic valuation. -/
theorem intValuation_ne_zero (x : R) (hx : x ≠ 0) : v.intValuation x ≠ 0 := by
  rw [v.intValuation_if_neg hx]
  exact WithZero.coe_ne_zero

/-- Nonzero divisors have nonzero valuation. -/
theorem intValuation_ne_zero' (x : nonZeroDivisors R) : v.intValuation x ≠ 0 :=
  v.intValuation_ne_zero x (nonZeroDivisors.coe_ne_zero x)

/-- Nonzero divisors have valuation greater than zero. -/
theorem intValuation_zero_lt (x : nonZeroDivisors R) : 0 < v.intValuation x := by
  rw [v.intValuation_if_neg (nonZeroDivisors.coe_ne_zero x)]
  exact WithZero.zero_lt_coe _

/-- The `v`-adic valuation on `R` is bounded above by 1. -/
theorem intValuation_le_one (x : R) : v.intValuation x ≤ 1 := by
  obtain rfl | hx := eq_or_ne x 0
  · simp
  · rw [v.intValuation_if_neg hx, ← exp_zero, exp_le_exp, Right.neg_nonpos_iff]
    exact Int.natCast_nonneg _

/-- The `v`-adic valuation of `r : R` is less than 1 if and only if `v` divides the ideal `(r)`. -/
theorem intValuation_lt_one_iff_dvd (r : R) :
    v.intValuation r < 1 ↔ v.asIdeal ∣ Ideal.span {r} := by
  by_cases hr : r = 0
  · simp [hr]
  · rw [v.intValuation_if_neg hr, ← exp_zero, exp_lt_exp,
      neg_lt_zero, ← Int.ofNat_zero, Int.ofNat_lt, zero_lt_iff]
    have h : (Ideal.span {r} : Ideal R) ≠ 0 := by
      rw [Ne, Ideal.zero_eq_bot, Ideal.span_singleton_eq_bot]
      exact hr
    exact Associates.count_ne_zero_iff_dvd h v.irreducible

/-- The `v`-adic valuation of `r : R` is less than 1 if and only if `r ∈ v`. -/
theorem intValuation_lt_one_iff_mem (r : R) :
    v.intValuation r < 1 ↔ r ∈ v.asIdeal := by
  rw [intValuation_lt_one_iff_dvd, Ideal.dvd_span_singleton]

set_option backward.isDefEq.respectTransparency.types false in
/-- The `v`-adic valuation of `r : R` is equal to 1 if and only if `r ∈ vᶜ`. -/
theorem intValuation_eq_one_iff_mem_primeCompl (r : R) :
    v.intValuation r = 1 ↔ r ∈ v.asIdeal.primeCompl := by
  simp [Ideal.primeCompl, ← intValuation_lt_one_iff_mem, LE.le.ge_iff_eq (intValuation_le_one v r)]

/-- The `v`-adic valuation of `r : R` is less than `WithZero.exp (-n)` if and only if
`vⁿ` divides the ideal `(r)`. -/
theorem intValuation_le_pow_iff_dvd (r : R) (n : ℕ) :
    v.intValuation r ≤ exp (-(n : ℤ)) ↔ v.asIdeal ^ n ∣ Ideal.span {r} := by
  by_cases hr : r = 0
  · simp_rw [hr, Valuation.map_zero, Ideal.dvd_span_singleton, zero_le, Submodule.zero_mem]
  · rw [v.intValuation_if_neg hr, exp_le_exp, neg_le_neg_iff, Int.ofNat_le,
      Ideal.dvd_span_singleton, ← Associates.le_singleton_iff,
      Associates.prime_pow_dvd_iff_le (Associates.mk_ne_zero'.mpr hr) v.associates_irreducible]

/-- The `v`-adic valuation of `r : R` is less than `WithZero.exp (-n)` if and only if
`r ∈ vⁿ`. -/
theorem intValuation_le_pow_iff_mem (r : R) (n : ℕ) :
    v.intValuation r ≤ exp (-(n : ℤ)) ↔ r ∈ v.asIdeal ^ n := by
  rw [intValuation_le_pow_iff_dvd, Ideal.dvd_span_singleton]

theorem intValuation_le_exp_iff_le_emultiplicity {r : R} {n : ℕ} :
    v.intValuation r ≤ exp (-(n : ℤ)) ↔ n ≤ emultiplicity v.asIdeal (Ideal.span {r}) := by
  rw [intValuation_le_pow_iff_dvd, pow_dvd_iff_le_emultiplicity]

theorem exp_le_intValuation_iff_emultiplicity_le {r : R} {n : ℕ} :
    exp (-(n : ℤ)) ≤ v.intValuation r ↔ emultiplicity v.asIdeal (Ideal.span {r}) ≤ n := by
  rw [← ENat.lt_natCast_add_one_iff, ← ENat.natCast_one, ← ENat.natCast_add,
    emultiplicity_lt_iff_not_dvd, ← intValuation_le_pow_iff_dvd, not_le, Nat.cast_add, Nat.cast_one,
    neg_add, exp_add, exp_neg 1, mul_inv_lt_iff₀ (by simp)]
  by_cases hv : v.intValuation r = 0
  · simp [hv]
  · rw [lt_mul_exp_iff_le hv]

/-- There exists `π : R` with `v`-adic valuation `WithZero.exp (-1)`. -/
theorem intValuation_exists_uniformizer :
    ∃ π : R, v.intValuation π = WithZero.exp (-1 : ℤ) := by
  have hv : Irreducible (Associates.mk v.asIdeal) := v.associates_irreducible
  have hlt : v.asIdeal ^ 2 < v.asIdeal := by
    rw [← Ideal.dvdNotUnit_iff_lt]
    exact ⟨v.ne_bot, v.asIdeal, Ideal.isUnit_iff.not.mpr v.isPrime.ne_top, sq v.asIdeal⟩
  obtain ⟨π, mem, notMem⟩ := SetLike.exists_of_lt hlt
  have hπ : Associates.mk (Ideal.span {π}) ≠ 0 := by
    rw [Associates.mk_ne_zero']
    intro h
    rw [h] at notMem
    exact notMem (Submodule.zero_mem (v.asIdeal ^ 2))
  use π
  rw [intValuation_if_neg _ (Associates.mk_ne_zero'.mp hπ), exp_inj]
  apply congr_arg
  rw [← Int.ofNat_one, Int.natCast_inj]
  rw [← Ideal.dvd_span_singleton, ← Associates.mk_le_mk_iff_dvd] at mem notMem
  rw [← pow_one (Associates.mk v.asIdeal), Associates.prime_pow_dvd_iff_le hπ hv] at mem
  rw [Associates.mk_pow, Associates.prime_pow_dvd_iff_le hπ hv, not_le] at notMem
  exact Nat.eq_of_le_of_lt_succ mem notMem

instance : v.intValuation.IsNontrivial :=
  have ⟨π, hπ⟩ := v.intValuation_exists_uniformizer
  ⟨π, by aesop⟩

@[simp]
theorem intValuation_uniformizer (π : v.intValuation.Uniformizer) :
    v.intValuation (π.val : R) = WithZero.exp (-1) := by
  simpa [Valuation.IsUniformizer.val π.valuation_gt_one, Units.ext_iff]
    using Valuation.IsRankOneDiscrete.generator_eq_exp_neg_one_of_mem_range
      v.intValuation_exists_uniformizer

/-- The `I`-adic valuation of a generator of `I` equals `(-1 : ℤᵐ⁰)` -/
theorem intValuation_singleton {r : R} (hr : r ≠ 0) (hv : v.asIdeal = Ideal.span {r}) :
    v.intValuation r = exp (-1 : ℤ) := by
  rw [v.intValuation_if_neg hr, ← hv, Associates.count_self, Int.ofNat_one]
  exact v.associates_irreducible

@[simp]
theorem intValuation_eq_one_iff {v : HeightOneSpectrum R} {x : R} :
    v.intValuation x = 1 ↔ x ∉ v.asIdeal := by
  refine ⟨fun h ↦ by simp [← (intValuation_lt_one_iff_mem _ _).not, h], fun h ↦ ?_⟩
  exact le_antisymm (v.intValuation_le_one x) <| by
    simp [← not_lt, (v.intValuation_lt_one_iff_mem _).not, h]

/-! ### Adic valuations on the field of fractions `K` -/

variable (K) in
/-- The `v`-adic valuation of `x : K` is the valuation of `r` divided by the valuation of `s`,
where `r` and `s` are chosen so that `x = r/s`. -/
@[no_expose]
def valuation (v : HeightOneSpectrum R) : Valuation K ℤᵐ⁰ :=
  v.intValuation.extendToLocalization
    (fun r hr => Set.mem_compl <| v.intValuation_ne_zero' ⟨r, hr⟩) K

theorem valuation_def (x : K) :
    v.valuation K x =
      v.intValuation.extendToLocalization
        (fun r hr => Set.mem_compl (v.intValuation_ne_zero' ⟨r, hr⟩)) K x := by rw [valuation]

set_option backward.isDefEq.respectTransparency.types false in
/--
The `v`-adic valuation of `r / s : K` is the valuation of `r` divided by the valuation of `s`. -/
theorem valuation_of_mk' {r : R} {s : nonZeroDivisors R} :
    v.valuation K (IsLocalization.mk' K r s) = v.intValuation r / v.intValuation s := by
  rw [valuation_def, Valuation.extendToLocalization_mk', div_eq_mul_inv]

set_option backward.isDefEq.respectTransparency.types false in
open scoped algebraMap in
/-- The `v`-adic valuation on `K` extends the `v`-adic valuation on `R`. -/
theorem valuation_of_algebraMap (r : R) : v.valuation K r = v.intValuation r := by
  rw [valuation_def, Valuation.extendToLocalization_apply_map_apply]

open scoped algebraMap in
/-- The `v`-adic valuation on `R` is bounded above by 1. -/
theorem valuation_le_one (r : R) : v.valuation K r ≤ 1 := by
  rw [valuation_of_algebraMap]; exact v.intValuation_le_one r

open scoped algebraMap in
/-- The `v`-adic valuation of `r : R` is less than 1 if and only if `v` divides the ideal `(r)`. -/
theorem valuation_lt_one_iff_dvd (r : R) :
    v.valuation K r < 1 ↔ v.asIdeal ∣ Ideal.span {r} := by
  rw [valuation_of_algebraMap]; exact v.intValuation_lt_one_iff_dvd r

open scoped algebraMap in
/-- The `v`-adic valuation of `r : R` is less than 1 if and only if `r ∈ v`. -/
theorem valuation_lt_one_iff_mem (r : R) :
    v.valuation K r < 1 ↔ r ∈ v.asIdeal := by
  rw [valuation_of_algebraMap]; exact v.intValuation_lt_one_iff_mem r

@[simp]
theorem valuation_eq_one_iff_notMem {r : R} :
    v.valuation K (algebraMap R K r) = 1 ↔ r ∉ v.asIdeal := by
  rw [← HeightOneSpectrum.valuation_lt_one_iff_mem (K := K), le_antisymm_iff]
  simp [HeightOneSpectrum.valuation_le_one]

variable (K) in
open scoped algebraMap in
/-- The `v` adic valuation of `a / b : K` is `≤ 1` if and only if `b ∉ v`, provided that `a` and
`b` are coprime at `v`. -/
theorem valuation_div_le_one_iff (a : R) {b : R} (hb : b ≠ 0)
    (h : b ∈ v.asIdeal → a ∉ v.asIdeal) :
    v.valuation K (a / b) ≤ 1 ↔ b ∉ v.asIdeal := by
  refine ⟨fun hv ↦ ?_, fun hb ↦ by
    simp [valuation_of_algebraMap, intValuation_eq_one_iff.2 hb, intValuation_le_one]⟩
  contrapose! hv
  have ha₀ : a ≠ 0 := fun _ ↦ by simp_all
  have hva : v.valuation K a ≠ 0 := (Valuation.ne_zero_iff _).2 (by simp [ha₀])
  have hvb : v.valuation K b ≠ 0 := (Valuation.ne_zero_iff _).2 (by simp [hb])
  rw [← WithZero.log_lt_log one_ne_zero ((Valuation.ne_zero_iff _).2 (by simp [ha₀, hb])),
    map_div₀, WithZero.log_div hva hvb, WithZero.log_one, Int.sub_pos,
    WithZero.log_lt_log hvb hva]
  simpa [valuation_of_algebraMap, intValuation_eq_one_iff.2 <| h hv, intValuation_lt_one_iff_mem]

variable (K)

open scoped algebraMap in
/-- There exists `π : R` with `v`-adic valuation `WithZero.exp (-1)`. -/
theorem valuation_exists_uniformizer' :
    ∃ (π : R), (valuation K v) π = WithZero.exp (-1) := by
  have ⟨π, hπ⟩ := intValuation_exists_uniformizer v
  use π
  grind [valuation_of_algebraMap]

/-- There exists `π : K` with `v`-adic valuation `WithZero.exp (-1)`. -/
theorem valuation_exists_uniformizer : ∃ π : K,
    v.valuation K π = exp (-1 : ℤ) := by
  obtain ⟨r, hr⟩ := v.valuation_exists_uniformizer' K
  use (algebraMap _ _ r)

instance : Valuation.IsNontrivial (v.valuation K) :=
  have ⟨π, hπ⟩ := v.valuation_exists_uniformizer K
  ⟨π, by aesop⟩

lemma valuation_surjective :
    Function.Surjective (v.valuation K) := by
  intro x
  rcases GroupWithZero.eq_zero_or_unit x with (rfl | ⟨x, rfl⟩)
  · simp
  · obtain ⟨π, hπ⟩ := v.valuation_exists_uniformizer K
    refine ⟨π ^ (- log x.val), ?_⟩
    simp [hπ, exp_log]

/-- Uniformizers are nonzero. -/
theorem valuation_uniformizer_ne_zero : Classical.choose (v.valuation_exists_uniformizer K) ≠ 0 :=
  haveI hu := Classical.choose_spec (v.valuation_exists_uniformizer K)
  (Valuation.ne_zero_iff _).mp (ne_of_eq_of_ne hu WithZero.coe_ne_zero)

theorem mem_integers_of_valuation_le_one (x : K)
    (h : ∀ v : HeightOneSpectrum R, v.valuation K x ≤ 1) : x ∈ (algebraMap R K).range := by
  obtain ⟨⟨n, d, hd⟩, hx⟩ := IsLocalization.surj (nonZeroDivisors R) x
  obtain rfl : x = IsLocalization.mk' K n ⟨d, hd⟩ := IsLocalization.eq_mk'_iff_mul_eq.mpr hx
  obtain rfl | hn0 := eq_or_ne n 0
  · simp
  have hd0 := nonZeroDivisors.ne_zero hd
  suffices Ideal.span {d} ∣ (Ideal.span {n} : Ideal R) by
    obtain ⟨z, rfl⟩ := Ideal.span_singleton_le_span_singleton.1 (Ideal.le_of_dvd this)
    use z
    rw [map_mul, mul_comm, mul_eq_mul_left_iff] at hx
    exact (hx.resolve_right fun h => by simp [hd0] at h).symm
  have ine {r : R} : r ≠ 0 → Ideal.span {r} ≠ ⊥ := mt Ideal.span_singleton_eq_bot.mp
  rw [← Associates.mk_le_mk_iff_dvd, ← Associates.factors_le, Associates.factors_mk _ (ine hn0),
    Associates.factors_mk _ (ine hd0), WithTop.coe_le_coe, Multiset.le_iff_count]
  rintro ⟨v, hv⟩
  obtain ⟨v, rfl⟩ := Associates.mk_surjective v
  have hv' := hv
  rw [Associates.irreducible_mk, irreducible_iff_prime] at hv
  specialize h ⟨v, Ideal.isPrime_of_prime hv, hv.ne_zero⟩
  simp_rw [valuation_of_mk', intValuation_if_neg _ hn0, intValuation_if_neg _ hd0, ← exp_sub,
    ← exp_zero, exp_le_exp, Associates.factors_mk _ (ine hn0),
    Associates.factors_mk _ (ine hd0), Associates.count_some hv'] at h
  simpa using h

variable {K}

theorem eq_of_valuation_isEquiv_valuation {p q : HeightOneSpectrum R}
    (hpq : (valuation K p).IsEquiv (valuation K q)) : p = q := by
  simp_all [Valuation.isEquiv_iff_val_lt_one, HeightOneSpectrum.ext_iff, Ideal.ext_iff,
    ← valuation_lt_one_iff_mem (K := K)]

section Localization

open Localization

local instance : IsDedekindDomain
    (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors) :=
  IsLocalization.AtPrime.isDedekindDomain R v.asIdeal
    (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors)

local instance : IsLocalRing (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors) :=
  IsLocalization.AtPrime.isLocalRing
    (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors) v.asIdeal

variable (K) in
/-- Given a Dedekind domain `R` in `K`, its field of fractions, the localization of `R` at
a nonzero prime is a valuation subring of `K`. -/
def valuationSubringAtPrime : ValuationSubring K :=
  .ofSubring (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors).toSubring fun x ↦
    by simpa [IsLocalization.IsInteger] using ValuationRing.isInteger_or_isInteger
        (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors) x

open IsDedekindDomain

theorem valuationSubringAtPrime_toSubring : (valuationSubringAtPrime K v).toSubring
    = (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors).toSubring := rfl

open scoped algebraMap in
theorem valuationSubringAtPrime_le_valuation :
    valuationSubringAtPrime K v ≤ (valuation K v).valuationSubring := by
  rintro x ⟨a, s, hs, rfl⟩
  suffices (valuation K v) (a / (s : K)) ≤ 1 by rwa [division_def (a : K) s] at this
  rwa [valuation_div_le_one_iff (K := K) v a (by aesop) (fun _ ↦ by contradiction)]

instance : Algebra R (valuationSubringAtPrime K v) :=
  (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors).algebra'

instance : IsScalarTower R (valuationSubringAtPrime K v) K :=
  IsScalarTower.of_algebraMap_eq (fun _ ↦ rfl)

instance : IsDedekindDomain (valuationSubringAtPrime K v) :=
  IsLocalization.AtPrime.isDedekindDomain R v.asIdeal
    (subalgebra.ofField K _ v.asIdeal.primeCompl_le_nonZeroDivisors)

instance : Ring.KrullDimLE 1 (valuationSubringAtPrime K v) :=
  Ring.KrullDimLE.mk₁' (fun _ a _ ↦ IsPrime.to_maximal_ideal a)

instance : IsLocalization (v.asIdeal.primeCompl) (valuationSubringAtPrime K v) :=
  Localization.subalgebra.isLocalization_ofField K (v.asIdeal.primeCompl) _

end Localization

/-- Given `v : HeightOneSpectrum R`, the valuation associated to `v` has the localization of
  `R` at `v` as valuation subring. -/
theorem valuationSubringAtPrime_eq_valuationSubring :
    valuationSubringAtPrime K v = (v.valuation K).valuationSubring :=
  ValuationSubring.eq_of_le_of_ne_top _ (valuationSubringAtPrime_le_valuation v)
    (by simp only [ne_eq, Valuation.valuationSubring_eq_top_iff, not_not]; infer_instance)

/-- All `x : K` can be written as `n / d` or `d / n` with `n : R` and `d ∈ v.asIdealᶜ`. -/
lemma exists_primeCompl_mul_eq_or_mul_eq (x : K) :
    ∃ (n : R) (d : v.asIdeal.primeCompl), x * (algebraMap R K d) = (algebraMap R K n) ∨
        x * (algebraMap R K n) = (algebraMap R K d) := by
  -- It's already known that the localization of `R` at `v` is a (discrete) valuation ring, so
  -- write `x` or `x⁻¹` as `n / d` with `d ∈ vᶜ`.
  obtain (⟨r, hr⟩ | ⟨r, hr⟩) :=
    ValuationRing.isInteger_or_isInteger (valuationSubringAtPrime K v) x
  <;> obtain ⟨⟨n, d⟩, hnd⟩ := IsLocalization.surj v.asIdeal.primeCompl r
  <;> use n, d
  <;> apply_fun algebraMap _ K at hnd
  <;> grind [=_ IsScalarTower.algebraMap_apply]

/-- All `x ∈ 𝓞[K]` can be written as `n / d` with `n : R` and `d ∈ v.asIdealᶜ`. -/
theorem exists_primeCompl_mul_eq_of_integer (x : K) (hv : v.valuation K x ≤ 1) :
    ∃ (n : R) (d : v.asIdeal.primeCompl), x * (algebraMap R K d) = algebraMap R K n := by
  obtain ⟨n, d, (hnd | hnd)⟩ := exists_primeCompl_mul_eq_or_mul_eq v x
  · use n, d
  · refine ⟨d, ⟨n, ?_⟩, hnd⟩
    rw [← v.intValuation_eq_one_iff_mem_primeCompl]
    apply eq_one_of_one_le_mul_right hv (intValuation_le_one v n)
    rw [← (v.intValuation_eq_one_iff_mem_primeCompl d).mpr d.prop,
      ← valuation_of_algebraMap (K := K), ← valuation_of_algebraMap (K := K), ← map_mul, hnd]

/-- Given `a, b ∈ A` and `v b ≤ v a` we can find `y : A` such that `y * a` is close to `b` by
the valuation `v`. -/
theorem exists_intValuation_mul_sub_lt {a b : R} (hv : v.intValuation b ≤ v.intValuation a)
    (γ : Multiplicative ℤ) : ∃ y, v.intValuation (b - y * a) < γ := by
  -- If `a = 0`, then `b = 0`, so we can take `y = 0`.
  by_cases ha: a = 0
  · subst ha
    rw [map_zero, le_zero_iff] at hv
    exact ⟨0, by simp [hv]⟩
  · have hvaz := intValuation_ne_zero v a ha
    have hγz : WithZero.coe γ ≠ 0 := WithZero.coe_ne_zero
    -- Otherwise, find `n : ℕ` such that `exp (-n) < γ` and `exp(-n) < v a`.
    obtain ⟨n, hna, hnγ⟩ := exists_exp_neg_natCast_lt_and_lt hvaz hγz
    apply Exists.imp (fun _ h ↦ lt_of_le_of_lt h hnγ)
    -- `v b ≤ v a`, so `b ∈ v.asIdeal ^ -log (v a)`.
    -- From `irreducible_pow_sup_of_ge` we know that
    -- `v.asIdeal ^ -log (v a) = v.asIdeal ^ n ⊔ Ideal.span {a}`.
    -- So, `∃ z ∈ v.asIdeal ^ n, ∃ (y: R), b = z + y * a`. This gives `z` and `y` such that
    -- `b - y * a = z` and `v z ≤ exp (-n)`, as required.
    have hvn : emultiplicity v.asIdeal (Ideal.span {a}) ≤ n := by
      grw [← exp_le_intValuation_iff_emultiplicity_le, hna]
    have hb : b ∈ v.asIdeal ^ multiplicity v.asIdeal (Ideal.span {a}) := by
      rwa [← intValuation_le_pow_iff_mem, ← v.intValuation_eq_exp_neg_multiplicity ha]
    have hnz : Ideal.span {a} ≠ ⊥ := by rwa [ne_eq, Ideal.span_singleton_eq_bot]
    simpa [← Ideal.irreducible_pow_sup_of_ge hnz v.irreducible n hvn, Submodule.mem_sup,
      ← eq_sub_iff_add_eq, ← intValuation_le_pow_iff_mem, Ideal.mem_span_singleton'] using hb

/-- Given `x ∈ 𝒪[K]` we can find `a : A` such that `a` is close to `x` by the valuation `v`. -/
theorem exists_valuation_sub_lt_of_integer {x : K} (hv : v.valuation K x ≤ 1)
    (γ : (ℤᵐ⁰)ˣ) : ∃a, v.valuation K (algebraMap R K a - x) < γ := by
  -- Write `x = n / d`, with `v d = 1`.
  obtain ⟨n, ⟨d, hd⟩, hnd⟩ := exists_primeCompl_mul_eq_of_integer v x hv
  rw [← intValuation_eq_one_iff_mem_primeCompl] at hd
  have hd' : v.intValuation n ≤ v.intValuation d := by grw [v.intValuation_le_one n, hd]
  -- Get `a` such that `v (n - a * d) < γ` from the previous theorem.
  obtain ⟨a, hval⟩ := exists_intValuation_mul_sub_lt v hd' (WithZero.unitsWithZeroEquiv γ)
  rw [unitsWithZeroEquiv_apply, coe_unzero] at hval
  use a
  -- `v d = 1`, so `v (a - x) = v (x - a) = v (x - a) * v d = v (n - a * d) < γ`.
  suffices h : v.valuation K (algebraMap R K a - x) = v.intValuation (n - a * d) by rwa [h]
  rw [← valuation_of_algebraMap (K := K), Algebra.cast, map_sub _ n, map_mul, ← hnd, ← sub_mul,
    map_mul, valuation_of_algebraMap, hd, mul_one, Valuation.map_sub_swap]

/-! ### Completions with respect to adic valuations

Given a Dedekind domain `R` with field of fractions `K` and a maximal ideal `v` of `R`, we define
the completion of `K` with respect to its `v`-adic valuation, denoted `v.adicCompletion`, and its
ring of integers, denoted `v.adicCompletionIntegers`. -/


/-- `K` as a valued field with the `v`-adic valuation. -/
@[instance_reducible]
def adicValued : Valued K ℤᵐ⁰ :=
  Valued.mk' (v.valuation K)

theorem adicValued_apply {x : K} : v.adicValued.v x = v.valuation K x :=
  rfl

@[deprecated adicValued_apply (since := "2026-01-28")]
theorem adicValued_apply' (x : WithVal (v.valuation K)) :
    v.adicValued.v (WithVal.equiv _ x) = v.valuation K (WithVal.equiv _ x) :=
  rfl

variable (K)

/-- The completion of `K` with respect to its `v`-adic valuation, defined as a one-field structure
wrapping the uniform-space completion `(v.valuation K).Completion`. -/
structure adicCompletion where
  /-- Wrap an element of the underlying completion `(v.valuation K).Completion` into
  `adicCompletion`. -/
  ofCompletion ::
  /-- The underlying element of the completion `(v.valuation K).Completion`. -/
  toCompletion : (v.valuation K).Completion

namespace adicCompletion

open UniformSpace MonoidWithZeroHom MonoidWithZeroHom.ValueGroup₀ Filter Topology Valuation

/-- `adicCompletion.toCompletion` and `adicCompletion.ofCompletion` as an equivalence. -/
@[simps]
def equivCompletion : adicCompletion K v ≃ (v.valuation K).Completion where
  toFun := toCompletion
  invFun := ofCompletion
  left_inv _ := rfl
  right_inv _ := rfl

noncomputable instance : Field (adicCompletion K v) := fast_instance% (equivCompletion K v).field

/-- `adicCompletion.toCompletion` as a ring isomorphism onto the underlying completion. -/
@[simps! apply]
def equiv : adicCompletion K v ≃+* (v.valuation K).Completion where
  toEquiv := equivCompletion K v
  map_mul' _ _ := rfl
  map_add' _ _ := rfl

@[simp] lemma toCompletion_ofCompletion (x : (v.valuation K).Completion) :
    toCompletion (ofCompletion x : adicCompletion K v) = x := rfl
@[simp] lemma ofCompletion_toCompletion (x : adicCompletion K v) :
    ofCompletion x.toCompletion = x := rfl

@[simp] lemma toCompletion_zero : (0 : adicCompletion K v).toCompletion = 0 := rfl
@[simp] lemma toCompletion_one : (1 : adicCompletion K v).toCompletion = 1 := rfl
@[simp] lemma toCompletion_add (x y : adicCompletion K v) :
    (x + y).toCompletion = x.toCompletion + y.toCompletion := rfl
@[simp] lemma toCompletion_mul (x y : adicCompletion K v) :
    (x * y).toCompletion = x.toCompletion * y.toCompletion := rfl

theorem toCompletion_surjective : Function.Surjective (toCompletion (K := K) (v := v)) :=
  (equivCompletion K v).surjective

theorem ofCompletion_surjective : Function.Surjective (ofCompletion (K := K) (v := v)) :=
  (equivCompletion K v).symm.surjective

noncomputable instance : UniformSpace (adicCompletion K v) := .comap toCompletion inferInstance

theorem isUniformInducing_toCompletion :
    IsUniformInducing (toCompletion (K := K) (v := v)) := ⟨rfl⟩

instance : IsUniformAddGroup (adicCompletion K v) :=
  IsUniformInducing.isUniformAddGroup (equiv K v).toRingHom (isUniformInducing_toCompletion K v)

/-- The `v`-adic valuation on `adicCompletion K v`, transported from the completion along `equiv`.
-/
noncomputable def valuation : Valuation (adicCompletion K v) ℤᵐ⁰ :=
  Valued.v.comap (equiv K v).toRingHom

theorem valueGroup_eq :
    valueGroup (.ofClass (valuation K v)) =
      valueGroup (.ofClass (Valued.v : Valuation (v.valuation K).Completion ℤᵐ⁰)) := by
  simp [valuation, valueGroup, valueMonoid, ← (toCompletion_surjective K v).range_comp]; rfl

/-- The multiplicative equivalence between the value group of the completion's valuation, pulled
back along `equiv`, and that of the completion. -/
def valueGroupEquiv :
    valueGroup (.ofClass (valuation K v)) ≃*
      valueGroup (.ofClass (Valued.v : Valuation (v.valuation K).Completion ℤᵐ⁰)) where
  __ := Equiv.setCongr (by rw [valueGroup_eq K v])
  map_mul' _ _ := rfl

@[simp] theorem coe_valueGroupEquiv (a : valueGroup (.ofClass (valuation K v))) :
    ((valueGroupEquiv K v a : _) : ℤᵐ⁰ˣ) = a := rfl

/-- The order-preserving multiplicative equivalence between the `ValueGroup₀` of the completion's
valuation, pulled back along `equiv`, and that of the completion. -/
noncomputable def valueGroupOrderIso :
    ValueGroup₀ (.ofClass (valuation K v)) ≃*o
      ValueGroup₀ (.ofClass (Valued.v : Valuation (v.valuation K).Completion ℤᵐ⁰)) where
  toFun := WithZero.map' (valueGroupEquiv K v)
  invFun := WithZero.map' (valueGroupEquiv K v).symm
  left_inv x := by match x with | 0 => simp | .coe a => simp
  right_inv y := by match y with | 0 => simp | .coe b => simp
  map_mul' := by simp
  map_le_map_iff' {a b} := by
    match a, b with
    | 0, 0 => simp
    | 0, .coe _ => simp
    | .coe _, 0 => simp
    | .coe a, .coe b => simp [← Subtype.coe_le_coe]

@[simp] theorem coe_valueGroupOrderIso_coe (a : valueGroup (.ofClass (valuation K v))) :
    valueGroupOrderIso K v (a : ValueGroup₀ _) = (valueGroupEquiv K v a : ValueGroup₀ _) := by
  simp [valueGroupOrderIso]

theorem embedding_valueGroupOrderIso (g : ValueGroup₀ (.ofClass (valuation K v))) :
    embedding (valueGroupOrderIso K v g) = embedding g := by
  match g with
  | 0 => simp [valueGroupOrderIso]
  | .coe a => simp [coe_valueGroupOrderIso_coe, embedding_apply, coe_valueGroupEquiv]

theorem valueGroupOrderIso_restrict (x : adicCompletion K v) :
    valueGroupOrderIso K v ((valuation K v).restrict x) =
      Valued.v.restrict (toCompletion x) := by
  apply embedding_strictMono.injective
  rw [embedding_valueGroupOrderIso, embedding_restrict, embedding_restrict]; rfl

noncomputable instance : Valued (adicCompletion K v) ℤᵐ⁰ where
  v := valuation K v
  is_topological_valuation s := by
    rw [(isUniformInducing_toCompletion K v).isInducing.nhds_eq_comap 0, toCompletion_zero,
      Filter.mem_comap]
    refine ⟨fun ⟨t, ht, hts⟩ ↦ ?_, fun ⟨γ, hγ⟩ ↦ ?_⟩
    · obtain ⟨δ, hδ⟩ := Valued.mem_nhds_zero.1 ht
      refine ⟨Units.mapEquiv (valueGroupOrderIso K v).symm.toMulEquiv δ, fun x hx ↦ hts (hδ ?_)⟩
      rw [Set.mem_ofPred_eq] at hx ⊢
      simpa [← map_lt_map_iff (valueGroupOrderIso K v), valueGroupOrderIso_restrict] using hx
    · refine ⟨{y | Valued.v.restrict y < ↑(Units.mapEquiv (valueGroupOrderIso K v).toMulEquiv γ)},
        ?_, fun x hx ↦ hγ ?_⟩
      · rw [Valued.mem_nhds_zero]
        exact ⟨Units.mapEquiv (valueGroupOrderIso K v).toMulEquiv γ, subset_rfl⟩
      · rw [Set.mem_ofPred_eq, ← map_lt_map_iff (valueGroupOrderIso K v),
          valueGroupOrderIso_restrict]
        simpa using hx

noncomputable instance : CompleteSpace (adicCompletion K v) :=
  ((isUniformInducing_toCompletion K v).completeSpace_congr (toCompletion_surjective K v)).mpr
    inferInstance

/-- Coercion of an element of `WithVal (v.valuation K)` into the adic completion. -/
instance : Coe (WithVal (v.valuation K)) (adicCompletion K v) where
  coe x := ofCompletion (x : (v.valuation K).Completion)

/-- Coercion of an element of `K` into the adic completion. -/
instance (priority := 99) : Coe K (adicCompletion K v) where
  coe k := ofCompletion (k : (v.valuation K).Completion)

@[simp] lemma coe_toCompletion (k : K) :
    (↑k : adicCompletion K v).toCompletion = (k : (v.valuation K).Completion) := rfl

theorem valuedAdicCompletion_def {x : adicCompletion K v} :
    Valued.v x = Valued.extensionValuation x.toCompletion := rfl

@[simp] theorem valued_toCompletion (x : adicCompletion K v) :
    Valued.v x.toCompletion = Valued.v x := rfl

@[simp] theorem valued_ofCompletion (y : (v.valuation K).Completion) :
    Valued.v (ofCompletion y : adicCompletion K v) = Valued.v y := rfl

theorem valued_coe (k : K) :
    Valued.v (↑k : adicCompletion K v) = v.valuation K k := by
  simp

@[ext] theorem ext {x y : adicCompletion K v} (h : x.toCompletion = y.toCompletion) : x = y := by
  cases x; cases y; exact congrArg ofCompletion h

@[norm_cast] lemma coe_zero : ((0 : K) : adicCompletion K v) = 0 := by
  apply adicCompletion.ext; simp
@[norm_cast] lemma coe_one : ((1 : K) : adicCompletion K v) = 1 := by
  apply adicCompletion.ext; simp
@[norm_cast] lemma coe_add (x y : K) :
    ((x + y : K) : adicCompletion K v) = ↑x + ↑y := by
  apply adicCompletion.ext; simp [UniformSpace.Completion.coe_add]
@[norm_cast] lemma coe_mul (x y : K) :
    ((x * y : K) : adicCompletion K v) = ↑x * ↑y := by
  apply adicCompletion.ext; simp [UniformSpace.Completion.coe_mul]

/-- `toCompletion` as a uniform-space isomorphism onto the underlying completion. -/
def uniformEquiv : adicCompletion K v ≃ᵤ (v.valuation K).Completion where
  toEquiv := equivCompletion K v
  uniformContinuous_toFun := uniformContinuous_comap
  uniformContinuous_invFun :=
    (isUniformInducing_toCompletion K v).uniformContinuous_iff.mpr uniformContinuous_id

theorem continuous_toCompletion : Continuous (toCompletion (K := K) (v := v)) :=
  (uniformEquiv K v).continuous

theorem continuous_ofCompletion : Continuous (ofCompletion (K := K) (v := v)) :=
  (uniformEquiv K v).symm.continuous

instance : T0Space (adicCompletion K v) :=
  (uniformEquiv K v).toHomeomorph.isEmbedding.t0Space

end adicCompletion

lemma valuedAdicCompletion_surjective :
    Function.Surjective (Valued.v : (v.adicCompletion K) → ℤᵐ⁰) := by
  have h : Function.Surjective (Valued.v : (v.valuation K).Completion → ℤᵐ⁰) :=
    Valued.valuedCompletion_surjective_iff.mpr <| .of_comp (v.valuation_surjective K)
  exact h.comp (adicCompletion.toCompletion_surjective K v)

lemma adicCompletion_valueGroup_eq : MonoidWithZeroHom.valueGroup (.ofClass (Valued.v
      (R := adicCompletion K v))) =
    MonoidWithZeroHom.valueGroup (.ofClass (valuation K v)) := by
  ext n
  simp only [MonoidWithZeroHom.mem_valueGroup_iff_of_comm, ne_eq, MonoidWithZeroHom.coe_ofClass]
  refine ⟨fun ⟨a, ha0, x, hx⟩ ↦ ?_, fun ⟨a, ha0, x, hx⟩ ↦
    ⟨↑a, by simpa using ha0, ↑x, by simpa using hx⟩⟩
  obtain ⟨b, hb⟩ := valuation_surjective K v (Valued.v a)
  obtain ⟨y, hy⟩ := valuation_surjective K v (Valued.v x)
  exact ⟨b, by rw [hb]; exact ha0, y, by rw [hb, hy]; exact hx⟩

/-- The ring of integers of `adicCompletion`. -/
def adicCompletionIntegers : ValuationSubring (v.adicCompletion K) :=
  Valued.v.valuationSubring

instance : Inhabited (adicCompletionIntegers K v) :=
  ⟨0⟩

variable (R)

theorem mem_adicCompletionIntegers {x : v.adicCompletion K} :
    x ∈ v.adicCompletionIntegers K ↔ Valued.v x ≤ 1 :=
  Iff.rfl

theorem notMem_adicCompletionIntegers {x : v.adicCompletion K} :
    x ∉ v.adicCompletionIntegers K ↔ 1 < Valued.v x := by
  rw [not_congr <| mem_adicCompletionIntegers R K v]
  exact not_le

section AlgebraInstances

instance (priority := 100) adicValued.has_uniform_continuous_const_smul' :
    UniformContinuousConstSMul R (WithVal <| v.valuation K) :=
  uniformContinuousConstSMul_of_continuousConstSMul R (WithVal <| v.valuation K)

section Algebra
variable [Algebra S K]

instance adicValued.uniformContinuousConstSMul :
    UniformContinuousConstSMul S (WithVal <| v.valuation K) := by
  refine ⟨fun l ↦ ?_⟩
  simp_rw [WithVal.smul_right_def, Algebra.smul_def]
  exact (Ring.uniformContinuousConstSMul (WithVal <| v.valuation K)).uniformContinuous_const_smul _

open UniformSpace in
/-- The `S`-algebra structure on the underlying completion. -/
noncomputable instance instAlgebraCompletion : Algebra S ((v.valuation K).Completion) where
  toSMul := Completion.instSMul _ _
  algebraMap := Completion.coeRingHom.comp (algebraMap S (WithVal (v.valuation K)))
  commutes' r x := by
    induction x using Completion.induction_on with
    | hp =>
      exact isClosed_eq (continuous_const_mul _) (continuous_mul_const _)
    | ih x => rw [mul_comm]
  smul_def' r x := by
    induction x using Completion.induction_on with
    | hp =>
      exact isClosed_eq (continuous_const_smul _) (continuous_const_mul _)
    | ih x =>
      simp [Algebra.smul_def, Completion.algebraMap_def, WithVal.algebraMap_right_apply,
        Completion.coeRingHom]

noncomputable instance : Algebra S (v.adicCompletion K) :=
  fast_instance% (adicCompletion.equivCompletion K v).algebra S

theorem algebraMap_adicCompletion_toCompletion (r : S) :
    (algebraMap S (v.adicCompletion K) r).toCompletion =
      algebraMap S ((v.valuation K).Completion) r := rfl

instance {S₀ : Type*} [CommSemiring S₀] [Algebra S₀ S] [Algebra S₀ K] [IsScalarTower S₀ S K] :
    IsScalarTower S₀ S ((v.valuation K).Completion) :=
  .of_algebraMap_eq fun x ↦ by
    exact congrArg (UniformSpace.Completion.coeRingHom (α := WithVal (v.valuation K)))
      (IsScalarTower.algebraMap_apply S₀ S (WithVal (v.valuation K)) x)

instance {S₀ : Type*} [CommSemiring S₀] [Algebra S₀ S] [Algebra S₀ K] [IsScalarTower S₀ S K] :
    IsScalarTower S₀ S (v.adicCompletion K) :=
  .of_algebraMap_eq fun x ↦ by
    apply adicCompletion.ext
    rw [algebraMap_adicCompletion_toCompletion, algebraMap_adicCompletion_toCompletion,
      IsScalarTower.algebraMap_apply S₀ S ((v.valuation K).Completion)]

theorem coe_smul_adicCompletion (r : S) (x : WithVal (v.valuation K)) :
    (↑(r • x) : v.adicCompletion K) = r • (↑x : v.adicCompletion K) := by
  apply adicCompletion.ext
  exact UniformSpace.Completion.coe_smul r x

theorem algebraMap_adicCompletion : ⇑(algebraMap S <| v.adicCompletion K) = (↑) ∘ algebraMap S K :=
  rfl

variable {R} in
theorem denseRange_algebraMap : DenseRange (algebraMap K (v.adicCompletion K)) := by
  rw [algebraMap_adicCompletion]
  exact (adicCompletion.ofCompletion_surjective K v).denseRange.comp
    (UniformSpace.Completion.denseRange_coe.comp (WithVal.equiv _).symm.surjective.denseRange
      (UniformSpace.Completion.continuous_coe _))
    (adicCompletion.continuous_ofCompletion K v)

end Algebra

theorem coe_algebraMap_mem (r : R) : ↑((algebraMap R K) r) ∈ adicCompletionIntegers K v := by
  rw [mem_adicCompletionIntegers]
  change Valued.v (↑((algebraMap R K) r) : adicCompletion K v).toCompletion ≤ 1
  rw [Valued.valuedCompletion_apply]
  simpa using v.valuation_le_one _

instance : Algebra R (v.adicCompletionIntegers K) where
  smul r x :=
    ⟨r • (x : v.adicCompletion K), by
      rw [Algebra.smul_def]
      refine ValuationSubring.mul_mem _ _ _ ?_ x.2
      rw [algebraMap_adicCompletion]
      exact coe_algebraMap_mem _ _ v r⟩
  algebraMap :=
  { toFun r :=
      ⟨(algebraMap R K r : adicCompletion K v), coe_algebraMap_mem _ _ v r⟩
    map_one' := by ext; simp
    map_mul' x y := by
      ext
      simp [map_mul, UniformSpace.Completion.coe_mul]
    map_zero' := by ext; simp
    map_add' x y := by
      ext
      simp [map_add, UniformSpace.Completion.coe_add] }
  commutes' r x := by
    rw [mul_comm]
  smul_def' r x := by
    ext
    simp +instances only [Algebra.smul_def]
    rfl

@[simp]
lemma algebraMap_adicCompletionIntegers_apply (r : R) :
    algebraMap R (v.adicCompletionIntegers K) r = (algebraMap R K r : v.adicCompletion K) := by
  rfl

instance [FaithfulSMul R K] : FaithfulSMul R (v.adicCompletionIntegers K) := by
  rw [faithfulSMul_iff_algebraMap_injective]
  intro x y
  rw [Subtype.ext_iff]
  simp

variable {R K} in
open scoped algebraMap in -- to make the coercions from `R` fire
/-- The valuation on the completion agrees with the global valuation on elements of the
integer ring. -/
theorem valuedAdicCompletion_eq_valuation (r : R) :
    Valued.v (r : v.adicCompletion K) = v.valuation K r := by
  rw [← adicCompletion.valued_toCompletion]
  exact Valued.valuedCompletion_apply _

variable {R K} in
/-- The valuation on the completion agrees with the global valuation on elements of the field. -/
theorem valuedAdicCompletion_eq_valuation' (k : K) :
    Valued.v (k : v.adicCompletion K) = v.valuation K k := by
  rw [← adicCompletion.valued_toCompletion]
  exact Valued.valuedCompletion_apply _

variable {R K} in
open scoped algebraMap in -- to make the coercion from `R` fire
/-- A global integer is in the local integers. -/
lemma coe_mem_adicCompletionIntegers (r : R) :
    (r : adicCompletion K v) ∈ adicCompletionIntegers K v := by
  rw [mem_adicCompletionIntegers, valuedAdicCompletion_eq_valuation]
  exact valuation_le_one v r

@[simp]
theorem coe_smul_adicCompletionIntegers (r : R) (x : v.adicCompletionIntegers K) :
    (↑(r • x) : v.adicCompletion K) = r • (x : v.adicCompletion K) :=
  rfl

instance : Module.IsTorsionFree R (v.adicCompletionIntegers K) := .of_smul_eq_zero <| by simp

instance adicCompletion.instIsScalarTower' :
    IsScalarTower R (v.adicCompletionIntegers K) (v.adicCompletion K) where
  smul_assoc x y z := by simp only [Algebra.smul_def]; apply mul_assoc

end AlgebraInstances

variable {R}

open nonZeroDivisors algebraMap in
variable {K} in
lemma adicCompletion.mul_nonZeroDivisor_mem_adicCompletionIntegers (v : HeightOneSpectrum R)
    (a : v.adicCompletion K) : ∃ b ∈ R⁰, a * b ∈ v.adicCompletionIntegers K := by
  by_cases ha : a ∈ v.adicCompletionIntegers K
  · use 1
    simp [ha]
  · rw [notMem_adicCompletionIntegers] at ha
    -- let ϖ be a uniformiser
    obtain ⟨ϖ, hϖ⟩ := intValuation_exists_uniformizer v
    have : Valued.v (algebraMap R (v.adicCompletion K) ϖ) = (exp (1 : ℤ))⁻¹ := by
      simp [valuedAdicCompletion_eq_valuation, valuation_of_algebraMap, hϖ, exp]
    have hϖ0 : ϖ ≠ 0 := by rintro rfl; simp [exp_ne_zero.symm] at hϖ
    refine ⟨ϖ^(log (Valued.v a)).natAbs, pow_mem (mem_nonZeroDivisors_of_ne_zero hϖ0) _, ?_⟩
    -- now manually translate the goal (an inequality in ℤᵐ⁰) to an inequality of "log" of ℤ
    simp only [map_pow, mem_adicCompletionIntegers, map_mul, this, inv_pow, ← exp_nsmul, nsmul_one,
      Int.natCast_natAbs]
    exact mul_inv_le_one_of_le₀ (le_exp_log.trans (by simp [le_abs_self])) zero_le

instance : FaithfulSMul (v.adicCompletionIntegers K) (v.adicCompletion K) :=
  Subsemiring.faithfulSMul _

theorem adicCompletionIntegers.integers :
    (Valued.v : Valuation (v.adicCompletion K) ℤᵐ⁰).Integers ↥(adicCompletionIntegers K v) where
  hom_inj := FaithfulSMul.algebraMap_injective _ _
  map_le_one := by simp [mem_adicCompletionIntegers]
  exists_of_le_one := by simp [mem_adicCompletionIntegers]

variable {K v}

theorem adicCompletionIntegers.isUnit_iff_valued_eq_one {a : v.adicCompletionIntegers K} :
    IsUnit a ↔ Valued.v a.1 = 1 := by
  simp [Valuation.Integers.isUnit_iff_valuation_eq_one (integers K v)]

theorem adicCompletionIntegers.mem_units_iff_valued_eq_one {a : (v.adicCompletion K)ˣ} :
    a ∈ (v.adicCompletionIntegers K).units ↔ Valued.v a.1 = 1 := by
  refine ⟨fun h ↦ ?_, fun h ↦
     ⟨h.le, by simp [mem_adicCompletionIntegers, inv_le_one_iff₀, h.symm.le]⟩⟩
  convert! isUnit_iff_valued_eq_one.1 (Submonoid.unitsEquivIsUnitSubmonoid _ ⟨_, h⟩).2

section AbsoluteValue

open WithZeroMulInt NNReal

variable (v) {b : ℝ≥0} (hb : 1 < b) (r : R) (x : K)

/-- The `v`-adic absolute value function on `R` defined as `b` raised to negative `v`-adic
valuation, for some `b` in `ℝ≥0` -/
def intAdicAbvDef (r : R) : ℝ≥0 := toNNReal (ne_zero_of_lt hb) (v.intValuation r)

lemma isNonarchimedean_intAdicAbvDef : IsNonarchimedean (v.intAdicAbvDef hb) := by
  intro x y
  simp only [intAdicAbvDef]
  have h_mono := (toNNReal_strictMono hb).monotone
  rw [← h_mono.map_max]
  exact h_mono <| v.intValuation.map_add x y

/-- The `v`-adic absolute value on `R` defined as `b` raised to negative `v`-adic
valuation, for some `b` in `ℝ≥0` -/
def intAdicAbv : AbsoluteValue R ℝ where
  toFun r := v.intAdicAbvDef hb r
  map_mul' _ _ := by simp [intAdicAbvDef]
  nonneg' _ := zero_le_coe
  eq_zero' _ := by simp [intAdicAbvDef, intValuation_def]
  add_le' _ _ := (isNonarchimedean_intAdicAbvDef v hb).add_le fun _ ↦ bot_le

/-- The `v`-adic absolute value is nonarchimedean -/
theorem isNonarchimedean_intAdicAbv : IsNonarchimedean (v.intAdicAbv hb) :=
  isNonarchimedean_intAdicAbvDef v hb

theorem intAdicAbv_le_one : v.intAdicAbv hb r ≤ 1 := by
  simpa [intAdicAbv, intAdicAbvDef, toNNReal_le_one_iff hb] using intValuation_le_one v r

theorem intAdicAbv_lt_one_iff : v.intAdicAbv hb r < 1 ↔ r ∈ v.asIdeal := by
  simpa [intAdicAbv, intAdicAbvDef, toNNReal_lt_one_iff hb] using intValuation_lt_one_iff_mem v r

theorem intAdicAbv_eq_one_iff : v.intAdicAbv hb r = 1 ↔ r ∉ v.asIdeal := by
  contrapose
  rw [← v.intAdicAbv_lt_one_iff hb, ne_iff_lt_iff_le]
  exact intAdicAbv_le_one v hb r

/-- The `v`-adic absolute value function on `K` defined as `b` raised to negative `v`-adic
valuation, for some `b` in `ℝ≥0` -/
def adicAbvDef (x : K) : ℝ≥0 := toNNReal (ne_zero_of_lt hb) (v.valuation K x)

lemma isNonarchimedean_adicAbvDef : IsNonarchimedean (α := K) (v.adicAbvDef hb) := by
  intro x y
  simp only [adicAbvDef]
  have h_mono := (toNNReal_strictMono hb).monotone
  rw [← h_mono.map_max]
  exact h_mono ((v.valuation _).map_add x y)

/-- The `v`-adic absolute value on `K` defined as `b` raised to negative `v`-adic
valuation, for some `b` in `ℝ≥0` -/
def adicAbv : AbsoluteValue K ℝ where
  toFun x := v.adicAbvDef hb x
  map_mul' _ _ := by simp [adicAbvDef]
  nonneg' _ := zero_le_coe
  eq_zero' _ := by simp [adicAbvDef]
  add_le' _ _ := (isNonarchimedean_adicAbvDef v hb).add_le fun _ ↦ bot_le

/-- The `v`-adic absolute value is nonarchimedean -/
theorem isNonarchimedean_adicAbv : IsNonarchimedean (α := K) (v.adicAbv hb) :=
  isNonarchimedean_adicAbvDef v hb

/-- The `v`-adic absolute value of `r / s : K` is the absolute value of `r` divided by the absolute
value of `s`. -/
theorem adicAbv_of_mk' {s : nonZeroDivisors R} :
    v.adicAbv hb (IsLocalization.mk' K r s) = v.intAdicAbv hb r / v.intAdicAbv hb s := by
  simp [adicAbv, adicAbvDef, intAdicAbv, intAdicAbvDef, valuation_of_algebraMap]

/-- The `v`-adic absolute value on `K` extends the `v`-adic absolute value on `R`. -/
theorem adicAbv_of_algebraMap (r : R) : v.adicAbv hb (algebraMap R K r) = v.intAdicAbv hb r := by
  simp [adicAbv, adicAbvDef, intAdicAbv, intAdicAbvDef, valuation_of_algebraMap]

theorem adicAbv_coe_le_one : v.adicAbv hb (algebraMap R K r) ≤ 1 := by
  rw [adicAbv_of_algebraMap]
  exact intAdicAbv_le_one v hb r

theorem adicAbv_coe_lt_one_iff : v.adicAbv hb (algebraMap R K r) < 1 ↔ r ∈ v.asIdeal := by
  rw [adicAbv_of_algebraMap]
  exact intAdicAbv_lt_one_iff v hb r

theorem adicAbv_coe_eq_one_iff : v.adicAbv hb (algebraMap R K r) = 1 ↔ r ∉ v.asIdeal := by
  rw [adicAbv_of_algebraMap]
  exact intAdicAbv_eq_one_iff v hb r

end AbsoluteValue

end IsDedekindDomain.HeightOneSpectrum

namespace Rat

open IsDedekindDomain.HeightOneSpectrum

variable {R : Type*} [CommRing R] [IsDedekindDomain R] [Algebra R ℚ] [IsFractionRing R ℚ]

theorem valuation_le_one_iff_den {𝔭 : HeightOneSpectrum R} {x : ℚ} :
    𝔭.valuation ℚ x ≤ 1 ↔ ↑x.den ∉ 𝔭.asIdeal := by
  have : CharZero R := ⟨.of_comp (f := algebraMap R ℚ) (by simpa using Nat.cast_injective)⟩
  have : (x.den : R) ≠ 0 := by simp
  simp [x.num_div_den, ← 𝔭.valuation_div_le_one_iff ℚ x.num this
    (Ideal.IsPrime.notMem_of_isCoprime_of_mem (mod_cast x.isCoprime_num_den.symm.intCast))]

end Rat
